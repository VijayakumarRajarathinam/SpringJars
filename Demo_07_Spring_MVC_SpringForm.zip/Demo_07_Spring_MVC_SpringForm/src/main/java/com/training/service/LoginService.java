package com.training.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.business.bean.LoginBean;
import com.training.dao.LoginDAO;

@Service
public class LoginService {

	@Autowired
	private LoginDAO loginDAO;

	public String validateLogin(LoginBean loginBean) {
        System.out.println("Service class invoked");
		return loginDAO.validateLogin(loginBean);

	}

}
