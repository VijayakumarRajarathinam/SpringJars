package com.training.ltt.dao;

import org.springframework.data.repository.CrudRepository;

import com.training.ltt.entity.EmployeeEntityBean;
/*
CrudRepository
✔ Provides basic CRUD operations.
✔ Methods like:
		save(),
		findById(),
		findAll(),
		delete(),
		count(), etc.

Usage: public interface EmployeeRepository extends CrudRepository<Employee, Integer> { }

PagingAndSortingRepository
✔ Extends CrudRepository.
✔ Adds pagination and sorting support.

Extra methods:
findAll(Pageable pageable)
findAll(Sort sort)

Usage:
public interface EmployeeRepository 
       extends PagingAndSortingRepository<Employee, Integer> { }



JpaRepository (Most Commonly Used)
✔ Extends PagingAndSortingRepository.
✔ Adds JPA-specific features.
✔ Includes:

Batch operations
Flush support
Delete-in-bulk
Better collection handling

Common methods:
saveAll()
deleteInBatch()
getOne()
findAll()
saveAndFlush()

*/
/*
Method	INSERT Execution Time
save()	Executes immediately (may trigger a SQL INSERT instantly)
persist()	INSERT may be delayed until flush (transaction commit or em.flush())
*/


public interface EmployeeDAO extends CrudRepository<EmployeeEntityBean, Integer>{
	

}
