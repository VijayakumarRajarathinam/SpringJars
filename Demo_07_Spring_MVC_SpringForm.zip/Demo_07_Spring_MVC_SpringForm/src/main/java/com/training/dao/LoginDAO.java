package com.training.dao;

import org.springframework.stereotype.Repository;

import com.training.business.bean.LoginBean;

@Repository
public class LoginDAO {

	public String validateLogin(LoginBean loginBean) {
		System.out.println("DAO class invoked");
		
		String uName = loginBean.getUserName();
		String password = loginBean.getPassword();

		if (uName.equals("System") && password.equals("admin@123")) {
			return "success";
		} 
		else {
			return "faliure";
		}
	}
}
